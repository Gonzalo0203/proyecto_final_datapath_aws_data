package pe.com.proyectoiot.example.main

import java.util.Calendar
import sys.process._
import org.apache.hadoop.fs._
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain
import org.apache.spark._
import org.apache.spark.streaming._
import com.amazonaws.services.kinesis.AmazonKinesis
import scala.collection.JavaConverters._
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.kinesis.KinesisInputDStream
import org.apache.spark.streaming.{Seconds, StreamingContext}
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.InitialPositionInStream
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.streaming.dstream.DStream
import com.amazonaws.regions.RegionUtils
import com.amazonaws.services.kinesis.AmazonKinesisClient
import org.apache.log4j.{Level, Logger}
import com.audienceproject.spark.dynamodb.implicits._

object consumerKinesisSparkStreaming {
  def getRegionNameByEndpoint(endpoint: String): String = {
    val uri = new java.net.URI(endpoint)
    RegionUtils.getRegionsForService(AmazonKinesis.ENDPOINT_PREFIX)
      .asScala
      .find(_.getAvailableEndpoints.asScala.toSeq.contains(uri.getHost))
      .map(_.getName)
      .getOrElse(
        throw new IllegalArgumentException(s"Could not resolve region for endpoint: $endpoint"))
  }

  def main(args: Array[String]) {

    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    val conf = new SparkConf().setAppName("KinesisSparkExample").setMaster("local[*]")
    val ssc = new StreamingContext(conf, Seconds(1))
    println("Starting application realtime Spark Streaming with Kinesis Data Streams")
    val Array(appName, streamName, endpointUrl, pathS3) = args
    println(streamName)
    val credentials = new DefaultAWSCredentialsProviderChain().getCredentials()

    require(credentials != null,
      "No AWS credentials found. Please specify credentials using one of the methods specified " +
        "in http://docs.aws.amazon.com/AWSSdkDocsJava/latest/DeveloperGuide/credentials.html")
    val kinesisClient = new AmazonKinesisClient(credentials)
    kinesisClient.setEndpoint(endpointUrl)
    val numShards = kinesisClient.describeStream(streamName).getStreamDescription().getShards().size
    println("Num of shards : " + numShards)

    val numStreams = numShards
    val batchInterval = Milliseconds(100)
    val kinesisCheckpointInterval = batchInterval
    val regionName = getRegionNameByEndpoint(endpointUrl)

    println("Region : " + regionName)

    val kinesisStreams = (0 until numStreams).map { i =>
      KinesisInputDStream.builder
        .streamingContext(ssc)
        .streamName(streamName)
        .endpointUrl(endpointUrl)
        .regionName(regionName)
        .initialPositionInStream(InitialPositionInStream.LATEST)
        .checkpointAppName(appName)
        .checkpointInterval(kinesisCheckpointInterval)
        .storageLevel(StorageLevel.MEMORY_AND_DISK_2)
        .build()
    }

    val unionStreams = ssc.union(kinesisStreams)

    val inputStreamData = unionStreams.map { byteArray =>
      val Array(id, read_date, device, humidity, temperature) = new String(byteArray).split(",")
      StreamData(id, read_date, device, humidity, temperature)
    }

    val inputStream: DStream[StreamData] = inputStreamData

    inputStream.window(Seconds(5)).foreachRDD { rdd =>
      val spark = SparkSession.builder.config(rdd.sparkContext.getConf).getOrCreate()
      import spark.implicits._

      val cal = Calendar.getInstance()
      val date = cal.get(Calendar.DATE)
      val year = cal.get(Calendar.YEAR)
      val month = cal.get(Calendar.MONTH)
      val day = cal.get(Calendar.DAY_OF_MONTH)
      val minute = cal.get(Calendar.MINUTE)
      val second = cal.get(Calendar.SECOND)
      val r = scala.util.Random
      val concat_date = year.toString() + month.toString() + day.toString() + minute.toString() + second.toString() + r.nextInt(100).toString()

      val inputStreamDataDF = rdd.toDF()
      inputStreamDataDF.createOrReplaceTempView("sensor_farming")

	    val dataDumpDF = spark.sql("SELECT * FROM sensor_farming")
      val df_count = dataDumpDF.count()
      if( df_count > 0 ){
         dataDumpDF.show()
         dataDumpDF.write.parquet(pathS3 + "/" + concat_date)
      }
      

    }

    ssc.start()
    ssc.awaitTermination()
  }
}
case class StreamData(id: String, read_date: String, device: String, humidity : String, temperature : String)
